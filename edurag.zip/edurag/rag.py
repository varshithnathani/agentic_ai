import base64
import glob
import os
import shutil
import subprocess
import tempfile

import chromadb
import fitz  # PyMuPDF
from openai import OpenAI
from sentence_transformers import SentenceTransformer

LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.groq.com/openai/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")  
LLM_MODEL = os.getenv("LLM_MODEL", "openai/gpt-oss-120b")
LLM_MODEL_AUDIO = os.getenv("LLM_MODEL_AUDIO", "whisper-large-v3-turbo")
LLM_MODEL_VISION = os.getenv("LLM_MODEL_VISION", "qwen/qwen3.8-27b")

MAX_DISTANCE = 1.0  # cosine distance (0 = identical, 1 = unrelated); only clearly unrelated chunks are dropped
FRAME_EVERY = 30  # seconds between video frames described by the vision model; 0 disables it

client = OpenAI(base_url=LLM_BASE_URL, api_key=LLM_API_KEY, timeout=120)
embedder = SentenceTransformer("all-MiniLM-L6-v2")
store = chromadb.PersistentClient("chroma").get_or_create_collection(
    "materials", metadata={"hnsw:space": "cosine"}
)

NOT_FOUND = "I could not find this in the study materials."


def split(text, size=200, overlap=40):
    words = text.split()
    return [" ".join(words[i:i + size]) for i in range(0, max(len(words) - overlap, 1), size - overlap)] if words else []


def ffmpeg():
    if shutil.which("ffmpeg"):
        return "ffmpeg"
    import imageio_ffmpeg  # bundled fallback when ffmpeg is not installed on the system
    return imageio_ffmpeg.get_ffmpeg_exe()


def stamp(seconds):
    return f"{int(seconds) // 60}:{int(seconds) % 60:02d}"


def transcript_items(path, tmp):
    audio = f"{tmp}/audio.mp3"
    subprocess.run([ffmpeg(), "-y", "-loglevel", "error", "-i", path, "-vn", "-ac", "1", "-ar", "16000",
                    "-b:a", "32k", audio], check=True)
    with open(audio, "rb") as f:
        result = client.audio.transcriptions.create(model=LLM_MODEL_AUDIO, file=f, response_format="verbose_json")
    items, words, start = [], [], 0
    for seg in result.segments:
        if not words:
            start = seg.start
        words += seg.text.split()
        if len(words) >= 150:
            items.append((stamp(start), " ".join(words)))
            words = []
    if words:
        items.append((stamp(start), " ".join(words)))
    return items


def frame_items(path, tmp):
    subprocess.run([ffmpeg(), "-y", "-loglevel", "error", "-i", path, "-vf", f"fps=1/{FRAME_EVERY},scale=768:-2",
                    "-q:v", "4", f"{tmp}/frame%04d.jpg"], check=True)
    items = []
    for i, frame in enumerate(sorted(glob.glob(f"{tmp}/frame*.jpg"))):
        with open(frame, "rb") as f:
            image = base64.b64encode(f.read()).decode()
        reply = client.chat.completions.create(
            model=LLM_MODEL_VISION,
            temperature=0.2,
            extra_body={"reasoning_effort": "none"},
            messages=[{"role": "user", "content": [
                {"type": "text", "text": "This is a frame from a lecture video. Transcribe or summarize any slide, "
                 "board, diagram or code visible, in a few sentences. If nothing educational is shown, reply: none"},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image}"}},
            ]}],
        )
        text = reply.choices[0].message.content.strip()
        if text.lower().strip(".") != "none":
            items.append((stamp(i * FRAME_EVERY), "On screen: " + text))
    return items


def video_items(path):
    with tempfile.TemporaryDirectory() as tmp:
        items = transcript_items(path, tmp)
        if FRAME_EVERY:
            try:
                items += frame_items(path, tmp)
            except Exception:
                pass  # the transcript alone is still useful if frame analysis fails
    return items


def ingest(path, material_id, name):
    if path.lower().endswith(".pdf"):
        items = [(f"p. {page.number + 1}", chunk) for page in fitz.open(path) for chunk in split(page.get_text())]
    else:
        items = video_items(path)
    if items:
        docs = [text for _, text in items]
        store.add(
            ids=[f"{material_id}-{i}" for i in range(len(items))],
            documents=docs,
            metadatas=[{"material_id": material_id, "source": name, "loc": loc} for loc, _ in items],
            embeddings=embedder.encode(docs).tolist(),
        )
    return len(items)


def remove(material_id):
    store.delete(where={"material_id": material_id})


def where(meta):
    return meta.get("loc") or f"p. {meta['page']}"  # "page" is the key used by earlier uploads


def answer(question, k=5):
    if store.count() == 0:
        return {"answer": "No study materials have been uploaded yet.", "sources": []}
    hits = store.query(query_embeddings=embedder.encode([question]).tolist(), n_results=k)
    found = [(d, m) for d, m, dist in zip(hits["documents"][0], hits["metadatas"][0], hits["distances"][0])
             if dist <= MAX_DISTANCE]
    if not found:
        return {"answer": NOT_FOUND, "sources": []}
    context = "\n\n".join(f"[{m['source']}, {where(m)}]\n{d}" for d, m in found)
    reply = client.chat.completions.create(
        model=LLM_MODEL,
        temperature=0.2,
        messages=[
            {"role": "system", "content": "You are a teaching assistant for students. Answer using only the "
             "context provided, explaining clearly and concisely. If the context does not contain the answer, "
             f"reply exactly: {NOT_FOUND}"},
            {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"},
        ],
    )
    text = reply.choices[0].message.content.strip()
    if text.startswith(NOT_FOUND):
        return {"answer": text, "sources": []}
    sources = list({(m["source"], where(m)): {"source": m["source"], "loc": where(m)} for _, m in found}.values())
    return {"answer": text, "sources": sources}