const $ = (id) => document.getElementById(id);
let token = localStorage.getItem("token");
let role = localStorage.getItem("role");
let registering = false;

async function api(path, options = {}) {
  const res = await fetch("/api" + path, {
    ...options,
    headers: { Authorization: "Bearer " + token, ...options.headers },
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token) return logout();
  if (!res.ok) throw new Error(data.detail || "Something went wrong");
  return data;
}

const post = (path, body) =>
  api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

function logout() {
  localStorage.clear();
  location.reload();
}

$("logout").onclick = logout;

$("toggle").onclick = (e) => {
  e.preventDefault();
  registering = !registering;
  $("auth-btn").textContent = registering ? "Create account" : "Log in";
  $("toggle").textContent = registering ? "Have an account? Log in" : "New student? Create an account";
};

$("auth-form").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const data = await post(registering ? "/register" : "/login", {
      email: $("email").value,
      password: $("password").value,
    });
    localStorage.setItem("token", data.token);
    localStorage.setItem("role", data.role);
    location.reload();
  } catch (err) {
    $("auth-error").textContent = err.message;
  }
};

async function loadMaterials() {
  const items = await api("/materials");
  $("materials").innerHTML = items.length ? "" : '<li class="muted">No materials yet.</li>';
  for (const m of items) {
    const li = document.createElement("li");
    li.innerHTML = `<a href="/files/${m.filename}" target="_blank"></a>`;
    li.firstChild.textContent = m.name;
    if (role === "teacher") {
      const del = document.createElement("button");
      del.textContent = "Delete";
      del.onclick = async () => {
        await api("/materials/" + m.id, { method: "DELETE" });
        loadMaterials();
      };
      li.append(del);
    }
    $("materials").append(li);
  }
}

$("upload-form").onsubmit = async (e) => {
  e.preventDefault();
  const form = new FormData();
  form.append("file", $("file").files[0]);
  $("upload-btn").disabled = true;
  $("upload-btn").textContent = "Processing...";
  $("upload-error").textContent = "";
  try {
    await api("/materials", { method: "POST", body: form });
    $("upload-form").reset();
    loadMaterials();
  } catch (err) {
    $("upload-error").textContent = err.message;
  }
  $("upload-btn").disabled = false;
  $("upload-btn").textContent = "Upload";
};

function addMessage(cls, text, sources = []) {
  const div = document.createElement("div");
  div.className = "msg " + cls;
  div.textContent = text;
  if (sources.length) {
    const s = document.createElement("span");
    s.className = "src";
    s.textContent = "Sources: " + sources.map((x) => `${x.source} (p. ${x.page})`).join(", ");
    div.append(s);
  }
  $("messages").append(div);
  $("messages").scrollTop = $("messages").scrollHeight;
  return div;
}

$("chat-form").onsubmit = async (e) => {
  e.preventDefault();
  const question = $("question").value;
  $("question").value = "";
  addMessage("user", question);
  const pending = addMessage("bot", "Thinking...");
  try {
    const data = await post("/chat", { question });
    pending.remove();
    addMessage("bot", data.answer, data.sources);
  } catch (err) {
    pending.textContent = err.message;
  }
};

if (token) {
  $("auth").hidden = true;
  $("app").hidden = false;
  $("role").textContent = role === "teacher" ? "Teacher" : "Student";
  $("upload-form").hidden = role !== "teacher";
  $("chat").hidden = role === "teacher";
  loadMaterials();
}
