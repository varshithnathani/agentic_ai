import hashlib
import secrets
import shutil
import sqlite3
import uuid
from pathlib import Path

import openai
from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import rag

DB = "edurag.db"
UPLOADS = Path("uploads")
UPLOADS.mkdir(exist_ok=True)
app = FastAPI(title="EduRAG")


def run(sql, args=()):
    with sqlite3.connect(DB) as con:
        con.row_factory = sqlite3.Row
        cur = con.execute(sql, args)
        return cur.fetchall(), cur.lastrowid


def hash_pw(password, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000).hex()


def init():
    run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE, password TEXT, role TEXT)")
    run("CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER)")
    run("CREATE TABLE IF NOT EXISTS materials (id INTEGER PRIMARY KEY, name TEXT, filename TEXT)")
    if not run("SELECT 1 FROM users WHERE role='teacher'")[0]:
        run("INSERT INTO users (email, password, role) VALUES (?,?,'teacher')",
            ("teacher@edurag.com", hash_pw("teacher123")))


init()


class Credentials(BaseModel):
    email: str
    password: str


class Question(BaseModel):
    question: str


def current_user(authorization: str = Header("")):
    rows, _ = run("SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token=?",
                  (authorization.removeprefix("Bearer "),))
    if not rows:
        raise HTTPException(401, "Please log in")
    return rows[0]


def teacher_only(user=Depends(current_user)):
    if user["role"] != "teacher":
        raise HTTPException(403, "Teachers only")
    return user


def start_session(user_id, role):
    token = secrets.token_urlsafe(24)
    run("INSERT INTO sessions VALUES (?,?)", (token, user_id))
    return {"token": token, "role": role}


@app.post("/api/register")
def register(c: Credentials):
    if len(c.password) < 6:
        raise HTTPException(422, "Password must be at least 6 characters")
    try:
        _, uid = run("INSERT INTO users (email, password, role) VALUES (?,?,'student')",
                     (c.email.strip().lower(), hash_pw(c.password)))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Email already registered")
    return start_session(uid, "student")


@app.post("/api/login")
def login(c: Credentials):
    rows, _ = run("SELECT * FROM users WHERE email=?", (c.email.strip().lower(),))
    if not rows or rows[0]["password"] != hash_pw(c.password, rows[0]["password"].split("$")[0]):
        raise HTTPException(401, "Invalid email or password")
    return start_session(rows[0]["id"], rows[0]["role"])


@app.get("/api/materials")
def materials(user=Depends(current_user)):
    return [dict(r) for r in run("SELECT id, name, filename FROM materials ORDER BY id DESC")[0]]


@app.post("/api/materials")
def upload(file: UploadFile = File(...), user=Depends(teacher_only)):
    ext = Path(file.filename).suffix.lower()
    if ext not in (".pdf", ".mp4", ".mov", ".mkv", ".webm"):
        raise HTTPException(422, "Only PDF or video files (mp4, mov, mkv, webm) are allowed")
    filename = f"{uuid.uuid4().hex}{ext}"
    path = UPLOADS / filename
    with path.open("wb") as out:
        shutil.copyfileobj(file.file, out)
    _, mid = run("INSERT INTO materials (name, filename) VALUES (?,?)", (file.filename, filename))
    try:
        problem = "" if rag.ingest(str(path), mid, file.filename) else \
            "No readable text or speech found (scanned PDFs and silent videos are not supported)"
    except Exception as e:
        problem = f"Could not process this file: {e}"
    if problem:
        run("DELETE FROM materials WHERE id=?", (mid,))
        path.unlink()
        raise HTTPException(422, problem)
    return {"id": mid, "name": file.filename}


@app.delete("/api/materials/{mid}")
def delete(mid: int, user=Depends(teacher_only)):
    rows, _ = run("SELECT filename FROM materials WHERE id=?", (mid,))
    if not rows:
        raise HTTPException(404, "Not found")
    rag.remove(mid)
    (UPLOADS / rows[0]["filename"]).unlink(missing_ok=True)
    run("DELETE FROM materials WHERE id=?", (mid,))
    return {"ok": True}


@app.post("/api/chat")
def chat(q: Question, user=Depends(current_user)):
    try:
        return rag.answer(q.question)
    except openai.OpenAIError:
        raise HTTPException(502, "The AI model is not reachable. Check your Groq API key and connection.")


app.mount("/files", StaticFiles(directory=UPLOADS))
app.mount("/", StaticFiles(directory="static", html=True))
